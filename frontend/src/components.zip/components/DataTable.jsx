import React from 'react';
import { DataGrid } from '@mui/x-data-grid';

export default function DataTable({ rows, columns, loading }) {
  return (
    <div style={{ height: 500, width: '100%' }}>
      <DataGrid 
        rows={rows} 
        columns={columns} 
        pageSize={10} 
        rowsPerPageOptions={[10, 25, 50]} 
        loading={loading}
      />
    </div>
  );
}

import React from 'react';
import { Drawer, List, ListItem, ListItemIcon, ListItemText, Toolbar } from '@mui/material';
import * as Icons from '@mui/icons-material';
import { Link } from 'react-router-dom'; // ✅ import Link
import { styled } from '@mui/system';

const nav = [
  { text: 'Dashboard', icon: <Icons.Dashboard />, path: '/' },
  { text: 'Booking', icon: <Icons.CalendarMonth />, path: '/booking' },
  { text: 'Turfs', icon: <Icons.SportsTennis />, path: '/turfs' },
  { text: 'Amenities', icon: <Icons.Build />, path: '/amenities' },
  { text: 'Customers', icon: <Icons.People />, path: '/customers' },
  { text: 'Turf Owners', icon: <Icons.AccountBox />, path: '/turf-owners' },
  { text: 'Expenses', icon: <Icons.MoneyOff />, path: '/expenses' },
  { text: 'Reports', icon: <Icons.BarChart />, path: '/reports' },
  { text: 'Payments', icon: <Icons.CreditCard />, path: '/payments' },
  { text: 'Staffs', icon: <Icons.Group />, path: '/staffs' },
  { text: 'Notifications', icon: <Icons.Notifications />, path: '/notifications' },
  { text: 'Settings', icon: <Icons.Settings />, path: '/settings' },
];

// ✅ Style Link so it doesn't break MUI styling
const StyledLink = styled(Link)({
  textDecoration: 'none',
  color: 'inherit',
});

export default function Sidebar() {
  return (
    <Drawer variant="permanent" sx={{ width: 240, flexShrink: 0, [`& .MuiDrawer-paper`]: { width: 240, boxSizing: 'border-box' } }}>
      <Toolbar />
      <List>
        {nav.map(item => (
          <StyledLink to={item.path} key={item.text}>
            <ListItem button>
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItem>
          </StyledLink>
        ))}
      </List>
    </Drawer>
  );
}

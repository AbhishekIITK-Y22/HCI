import React, { useEffect, useState } from 'react';
import { Grid, Paper, Typography } from '@mui/material';
import api from '../api/axios';
import dayjs from 'dayjs';

export default function CalendarView({ month, year }) {
  const [events, setEvents] = useState([]);
  useEffect(() => {
    api.get(`/bookings/calendar?month=${month}&year=${year}`)
       .then(r => setEvents(r.data));
  }, [month, year]);

  const daysInMonth = dayjs(`${year}-${month}-01`).daysInMonth();
  return (
    <Grid container spacing={1}>
      {Array.from({ length: daysInMonth }, (_, i) => i + 1).map(day => {
        const evs = events.filter(e => dayjs(e.date).date() === day);
        return (
          <Grid item xs={12} sm={6} md={2} key={day}>
            <Paper sx={{ p:1, minHeight: 80 }}>
              <Typography variant="subtitle2">{day}</Typography>
              {evs.slice(0,2).map(e => (
                <Typography key={e._id} variant="caption">{e.coach}: {dayjs(e.start).format('HH:mm')}</Typography>
              ))}
              {evs.length > 2 && <Typography variant="caption">+{evs.length - 2} more</Typography>}
            </Paper>
          </Grid>
        );
      })}
    </Grid>
  );
}

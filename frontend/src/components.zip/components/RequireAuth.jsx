import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function RequireAuth({ children }) 
{
  if (import.meta.env.VITE_SKIP_AUTH === 'true') {
    return children; // allow everything in dev
  }
  const { user } = useContext(AuthContext);
  return user ? children : <Navigate to="/login" replace />;
}
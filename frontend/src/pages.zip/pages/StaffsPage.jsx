// src/pages/StaffsPage.jsx
import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, TextField, MenuItem } from '@mui/material';
import DataTable from '../components/DataTable';
import FormDialog from '../components/FormDialog';
import api from '../api/axios';

export default function StaffsPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dlgOpen, setDlgOpen] = useState(false);
  const [edit, setEdit] = useState({ name: '', role: '', email: '' });

  const fetch = () => {
    setLoading(true);
    api.get('/staffs')
       .then(r => setRows(r.data))
       .finally(() => setLoading(false));
  };
  useEffect(fetch, []);

  const columns = [
    { field: 'name',  headerName: 'Name',  width: 200 },
    { field: 'role',  headerName: 'Role',  width: 180 },
    { field: 'email', headerName: 'Email', width: 250 },
    {
      field: 'actions', headerName: 'Actions', width: 120,
      renderCell: p => (
        <Button size="small" onClick={() => { setEdit(p.row); setDlgOpen(true); }}>
          Edit
        </Button>
      )
    }
  ];

  const handleSave = () => {
    const req = edit._id
      ? api.put(`/staffs/${edit._id}`, edit)
      : api.post('/staffs', edit);
    req.then(() => {
      fetch();
      setDlgOpen(false);
      setEdit({ name: '', role: '', email: '' });
    });
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>Staff Members</Typography>
      <Button variant="contained" sx={{ mb: 2 }}
              onClick={() => { setEdit({ name: '', role: '', email: '' }); setDlgOpen(true); }}>
        Add Staff
      </Button>
      <DataTable rows={rows} columns={columns} loading={loading} />

      <FormDialog
        open={dlgOpen}
        title={edit._id ? 'Edit Staff' : 'Add Staff'}
        onClose={() => { setDlgOpen(false); setEdit({ name: '', role: '', email: '' }); }}
        onSave={handleSave}
      >
        <TextField
          fullWidth
          label="Name"
          margin="normal"
          value={edit.name}
          onChange={e => setEdit({ ...edit, name: e.target.value })}
        />
        <TextField
          fullWidth
          label="Role"
          margin="normal"
          select
          value={edit.role}
          onChange={e => setEdit({ ...edit, role: e.target.value })}
        >
          <MenuItem value="Admin">Admin</MenuItem>
          <MenuItem value="Manager">Manager</MenuItem>
          <MenuItem value="Staff">Staff</MenuItem>
        </TextField>
        <TextField
          fullWidth
          label="Email"
          margin="normal"
          value={edit.email}
          onChange={e => setEdit({ ...edit, email: e.target.value })}
        />
      </FormDialog>
    </Box>
);
}

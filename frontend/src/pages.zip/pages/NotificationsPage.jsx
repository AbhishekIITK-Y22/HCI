// src/pages/NotificationsPage.jsx
import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, TextField, MenuItem } from '@mui/material';
import DataTable from '../components/DataTable';
import FormDialog from '../components/FormDialog';
import api from '../api/axios';

export default function NotificationsPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dlgOpen, setDlgOpen] = useState(false);
  const [edit, setEdit] = useState({ message: '', type: '', date: '' });

  const fetch = () => {
    setLoading(true);
    api.get('/notifications')
       .then(r => setRows(r.data))
       .finally(() => setLoading(false));
  };
  useEffect(fetch, []);

  const columns = [
    { field: 'message', headerName: 'Message', width: 300 },
    { field: 'type',    headerName: 'Type',    width: 130 },
    { field: 'date',    headerName: 'Date',    width: 150 },
    {
      field: 'actions', headerName: 'Actions', width: 120,
      renderCell: p => (
        <Button size="small" onClick={() => { setEdit(p.row); setDlgOpen(true); }}>
          Edit
        </Button>
      )
    }
  ];

  const handleSave = () => {
    const req = edit._id
      ? api.put(`/notifications/${edit._id}`, edit)
      : api.post('/notifications', edit);
    req.then(() => {
      fetch();
      setDlgOpen(false);
      setEdit({ message: '', type: '', date: '' });
    });
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>Notifications</Typography>
      <Button variant="contained" sx={{ mb: 2 }}
              onClick={() => { setEdit({ message: '', type: '', date: '' }); setDlgOpen(true); }}>
        New Notification
      </Button>
      <DataTable rows={rows} columns={columns} loading={loading} />

      <FormDialog
        open={dlgOpen}
        title={edit._id ? 'Edit Notification' : 'Create Notification'}
        onClose={() => { setDlgOpen(false); setEdit({ message: '', type: '', date: '' }); }}
        onSave={handleSave}
      >
        <TextField
          fullWidth
          label="Message"
          margin="normal"
          value={edit.message}
          onChange={e => setEdit({ ...edit, message: e.target.value })}
        />
        <TextField
          fullWidth
          label="Type"
          select
          margin="normal"
          value={edit.type}
          onChange={e => setEdit({ ...edit, type: e.target.value })}
        >
          <MenuItem value="Reminder">Reminder</MenuItem>
          <MenuItem value="Alert">Alert</MenuItem>
        </TextField>
        <TextField
          fullWidth
          label="Date"
          type="datetime-local"
          margin="normal"
          InputLabelProps={{ shrink: true }}
          value={edit.date}
          onChange={e => setEdit({ ...edit, date: e.target.value })}
        />
      </FormDialog>
    </Box>
  );
}

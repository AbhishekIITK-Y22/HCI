// src/pages/Dashboard.jsx
import React, { useState, useEffect } from 'react';
import { Box, Grid, Typography } from '@mui/material';
import StatCard from '../components/StatCard';
import CalendarView from '../components/CalendarView';
import api from '../api/axios';
import dayjs from 'dayjs';

export default function Dashboard() {
  const [stats, setStats] = useState({});
  useEffect(() => {
    api.get('/stats').then(r => setStats(r.data));
  }, []);

  const cards = [
    { title: 'Pending Bookings', value: stats.pendingBookings || 0 },
    { title: 'Booking This Month', value: stats.bookingsThisMonth || 0 },
    { title: 'Registered Turfs', value: stats.registeredTurfs || 0 },
    { title: 'Registered Customers', value: stats.registeredCustomers || 0 },
    { title: 'Today’s Expense', value: stats.todayExpense || 0 },
    { title: 'Expense This Month', value: stats.expenseThisMonth || 0 },
    { title: 'Online Transactions', value: stats.onlineTransactions || 0 },
    { title: 'Total Transactions', value: stats.totalTransactions || 0 },
  ];

  const today = dayjs();
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>Dashboard</Typography>
      <Grid container spacing={2}>
        {cards.map((c, i) => (
          <Grid item xs={12} sm={6} md={3} key={i}>
            <StatCard title={c.title} value={c.value} />
          </Grid>
        ))}
      </Grid>
      <Box sx={{ mt: 4 }}>
        <Typography variant="h6" gutterBottom>Event Calendar</Typography>
        <CalendarView month={today.month() + 1} year={today.year()} />
      </Box>
    </Box>
  );
}

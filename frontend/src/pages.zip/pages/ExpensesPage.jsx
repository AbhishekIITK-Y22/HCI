// src/pages/ExpensesPage.jsx
import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, TextField, MenuItem } from '@mui/material';
import DataTable from '../components/DataTable';
import FormDialog from '../components/FormDialog';
import api from '../api/axios';

export default function ExpensesPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dlgOpen, setDlgOpen] = useState(false);
  const [edit, setEdit] = useState({ date: '', amount: '', type: '', description: '' });

  const fetch = () => {
    setLoading(true);
    api.get('/expenses')
       .then(r => setRows(r.data))
       .finally(() => setLoading(false));
  };
  useEffect(fetch, []);

  const columns = [
    { field: 'date',        headerName: 'Date',        width: 130 },
    { field: 'amount',      headerName: 'Amount',      width: 120 },
    { field: 'type',        headerName: 'Type',        width: 150 },
    { field: 'description', headerName: 'Description', width: 250 },
    {
      field: 'actions', headerName: 'Actions', width: 120,
      renderCell: p => (
        <Button size="small" onClick={() => { setEdit(p.row); setDlgOpen(true); }}>
          Edit
        </Button>
      )
    }
  ];

  const handleSave = () => {
    const req = edit._id
      ? api.put(`/expenses/${edit._id}`, edit)
      : api.post('/expenses', edit);
    req.then(() => {
      fetch();
      setDlgOpen(false);
      setEdit({ date: '', amount: '', type: '', description: '' });
    });
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>Expenses</Typography>
      <Button variant="contained" sx={{ mb: 2 }}
              onClick={() => { setEdit({ date: '', amount: '', type: '', description: '' }); setDlgOpen(true); }}>
        Record Expense
      </Button>
      <DataTable rows={rows} columns={columns} loading={loading} />

      <FormDialog
        open={dlgOpen}
        title={edit._id ? 'Edit Expense' : 'New Expense'}
        onClose={() => { setDlgOpen(false); setEdit({ date: '', amount: '', type: '', description: '' }); }}
        onSave={handleSave}
      >
        <TextField
          fullWidth
          label="Date"
          type="date"
          margin="normal"
          InputLabelProps={{ shrink: true }}
          value={edit.date}
          onChange={e => setEdit({ ...edit, date: e.target.value })}
        />
        <TextField
          fullWidth
          label="Amount"
          type="number"
          margin="normal"
          value={edit.amount}
          onChange={e => setEdit({ ...edit, amount: e.target.value })}
        />
        <TextField
          fullWidth
          label="Type"
          select
          margin="normal"
          value={edit.type}
          onChange={e => setEdit({ ...edit, type: e.target.value })}
        >
          <MenuItem value="Maintenance">Maintenance</MenuItem>
          <MenuItem value="Utilities">Utilities</MenuItem>
          <MenuItem value="Other">Other</MenuItem>
        </TextField>
        <TextField
          fullWidth
          label="Description"
          multiline
          rows={3}
          margin="normal"
          value={edit.description}
          onChange={e => setEdit({ ...edit, description: e.target.value })}
        />
      </FormDialog>
    </Box>
  );
}

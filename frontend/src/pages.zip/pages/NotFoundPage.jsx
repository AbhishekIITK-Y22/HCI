// src/pages/NotFoundPage.jsx
import React from 'react';
import { Box, Typography, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';

export default function NotFoundPage() {
  const nav = useNavigate();
  return (
    <Box
      sx={{ height: '100vh', display: 'flex', flexDirection: 'column',
            justifyContent: 'center', alignItems: 'center', p: 3 }}
    >
      <Typography variant="h2" gutterBottom>404</Typography>
      <Typography variant="h6" gutterBottom>Page Not Found</Typography>
      <Button variant="contained" onClick={() => nav('/')}>Go Home</Button>
    </Box>
  );
}

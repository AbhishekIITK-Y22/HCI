// src/pages/ProfilePage.jsx
import React, { useState, useEffect, useContext } from 'react';
import { Box, Typography, TextField, Button } from '@mui/material';
import api from '../api/axios';
import { AuthContext } from '../context/AuthContext';

export default function ProfilePage() {
  const { user, logout } = useContext(AuthContext);
  const [form, setForm] = useState({ name: '', email: '', password: '' });

  useEffect(() => {
    if (user) setForm({ name: user.name, email: user.email, password: '' });
  }, [user]);

  const handleSave = () => {
    api.put('/users/me', form).then(() => alert('Profile updated'));
  };

  return (
    <Box sx={{ p: 3, maxWidth: 400 }}>
      <Typography variant="h4" gutterBottom>My Profile</Typography>
      <TextField
        fullWidth
        label="Name"
        margin="normal"
        value={form.name}
        onChange={e => setForm({ ...form, name: e.target.value })}
      />
      <TextField
        fullWidth
        label="Email"
        margin="normal"
        value={form.email}
        onChange={e => setForm({ ...form, email: e.target.value })}
      />
      <TextField
        fullWidth
        label="New Password"
        type="password"
        margin="normal"
        value={form.password}
        onChange={e => setForm({ ...form, password: e.target.value })}
      />
      <Button variant="contained" onClick={handleSave} sx={{ mt: 2 }}>
        Save Changes
      </Button>
      <Button color="error" onClick={logout} sx={{ mt: 2, ml: 2 }}>
        Logout
      </Button>
    </Box>
  );
}

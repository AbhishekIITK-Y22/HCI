// src/pages/TurfDetailPage.jsx
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Box, Typography, Button, List, ListItem } from '@mui/material';
import api from '../api/axios';
import FormDialog from '../components/FormDialog';

export default function TurfDetailPage() {
  const { id } = useParams();
  const [turf, setTurf] = useState(null);
  const [dlgOpen, setDlgOpen] = useState(false);

  useEffect(() => {
    api.get(`/turfs/${id}`).then(r => setTurf(r.data));
  }, [id]);

  return (
    <Box sx={{ p: 3 }}>
      {turf ? (
        <>
          <Typography variant="h4">{turf.name}</Typography>
          <Typography color="textSecondary">{turf.location}</Typography>
          <Typography variant="h6" sx={{ mt: 2 }}>Slots</Typography>
          <List>
            {turf.slots.map(s => (
              <ListItem key={s._id}>
                {s.time} — {s.available ? 'Available' : 'Booked'}
              </ListItem>
            ))}
          </List>
          <Button variant="contained" onClick={() => setDlgOpen(true)}>
            Book Now
          </Button>
          <FormDialog
            open={dlgOpen}
            title="Book Turf"
            onClose={() => setDlgOpen(false)}
            onSave={() => {/* TODO: book slot */}}
          >
            {/* TODO: DatePicker/TimePicker & coach selection */}
          </FormDialog>
        </>
      ) : (
        <Typography>Loading...</Typography>
      )}
    </Box>
  );
}

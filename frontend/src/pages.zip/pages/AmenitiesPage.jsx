// src/pages/AmenitiesPage.jsx
import React, { useState, useEffect } from 'react';
import { Button, Typography, Box } from '@mui/material';
import DataTable from '../components/DataTable';
import FormDialog from '../components/FormDialog';
import api from '../api/axios';

export default function AmenitiesPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dlgOpen, setDlgOpen] = useState(false);
  const [edit, setEdit] = useState({});

  const fetch = () => {
    setLoading(true);
    api.get('/amenities').then(r => setRows(r.data)).finally(() => setLoading(false));
  };
  useEffect(fetch, []);

  const columns = [
    { field: 'name', headerName: 'Amenity', width: 200 },
    { field: 'description', headerName: 'Description', width: 300 },
    {
      field: 'actions', headerName: 'Actions', width: 120,
      renderCell: p => <Button size="small" onClick={()=>{ setEdit(p.row); setDlgOpen(true); }}>Edit</Button>
    }
  ];

  const handleSave = () => {
    const req = edit._id
      ? api.put(`/amenities/${edit._id}`, edit)
      : api.post('/amenities', edit);
    req.then(() => { fetch(); setDlgOpen(false); setEdit({}); });
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>Amenities</Typography>
      <Button variant="contained" sx={{ mb: 2 }} onClick={() => setDlgOpen(true)}>Add Amenity</Button>
      <DataTable rows={rows} columns={columns} loading={loading} />

      <FormDialog
        open={dlgOpen}
        title={edit._id ? 'Edit Amenity' : 'Add Amenity'}
        onClose={() => { setDlgOpen(false); setEdit({}); }}
        onSave={handleSave}
      >
        {/* TODO: MUI TextField for name & description bound to `edit` */}
      </FormDialog>
    </Box>
  );
}

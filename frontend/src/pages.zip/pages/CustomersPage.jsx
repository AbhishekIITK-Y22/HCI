// src/pages/CustomersPage.jsx
import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, TextField } from '@mui/material';
import DataTable from '../components/DataTable';
import FormDialog from '../components/FormDialog';
import api from '../api/axios';

export default function CustomersPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dlgOpen, setDlgOpen] = useState(false);
  const [edit, setEdit] = useState({ name: '', email: '', phone: '' });

  const fetch = () => {
    setLoading(true);
    api.get('/customers')
       .then(r => setRows(r.data))
       .finally(() => setLoading(false));
  };
  useEffect(fetch, []);

  const columns = [
    { field: 'name',  headerName: 'Name',  width: 200 },
    { field: 'email', headerName: 'Email', width: 250 },
    { field: 'phone', headerName: 'Phone', width: 150 },
    {
      field: 'actions', headerName: 'Actions', width: 120,
      renderCell: params => (
        <Button
          size="small"
          onClick={() => {
            setEdit(params.row);
            setDlgOpen(true);
          }}
        >
          Edit
        </Button>
      )
    }
  ];

  const handleSave = () => {
    const req = edit._id
      ? api.put(`/customers/${edit._id}`, edit)
      : api.post('/customers', edit);
    req.then(() => {
      fetch();
      setDlgOpen(false);
      setEdit({ name: '', email: '', phone: '' });
    });
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>Customers</Typography>
      <Button variant="contained" sx={{ mb: 2 }}
              onClick={() => { setEdit({ name: '', email: '', phone: '' }); setDlgOpen(true); }}>
        Add Customer
      </Button>
      <DataTable rows={rows} columns={columns} loading={loading} />

      <FormDialog
        open={dlgOpen}
        title={edit._id ? 'Edit Customer' : 'Add Customer'}
        onClose={() => { setDlgOpen(false); setEdit({ name: '', email: '', phone: '' }); }}
        onSave={handleSave}
      >
        <TextField
          fullWidth
          label="Name"
          margin="normal"
          value={edit.name}
          onChange={e => setEdit({ ...edit, name: e.target.value })}
        />
        <TextField
          fullWidth
          label="Email"
          margin="normal"
          value={edit.email}
          onChange={e => setEdit({ ...edit, email: e.target.value })}
        />
        <TextField
          fullWidth
          label="Phone"
          margin="normal"
          value={edit.phone}
          onChange={e => setEdit({ ...edit, phone: e.target.value })}
        />
      </FormDialog>
    </Box>
  );
}

// src/pages/SettingsPage.jsx
import React, { useState, useEffect } from 'react';
import { Box, Typography, TextField, Button, Switch, FormControlLabel } from '@mui/material';
import api from '../api/axios';

export default function SettingsPage() {
  const [cfg, setCfg] = useState({});
  useEffect(() => {
    api.get('/settings').then(r => setCfg(r.data));
  }, []);

  const handleSave = () => api.put('/settings', cfg);

  return (
    <Box sx={{ p: 3, maxWidth: 600 }}>
      <Typography variant="h4" gutterBottom>Settings</Typography>
      <TextField
        fullWidth
        label="Business Hours"
        margin="normal"
        value={cfg.businessHours || ''}
        onChange={e => setCfg({ ...cfg, businessHours: e.target.value })}
      />
      <FormControlLabel
        control={
          <Switch
            checked={cfg.enableNotifications || false}
            onChange={e => setCfg({ ...cfg, enableNotifications: e.target.checked })}
          />
        }
        label="Enable Notifications"
      />
      <Button variant="contained" sx={{ mt: 2 }} onClick={handleSave}>Save Settings</Button>
    </Box>
  );
}

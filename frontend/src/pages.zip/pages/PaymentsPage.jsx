// src/pages/PaymentsPage.jsx
import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, TextField, MenuItem } from '@mui/material';
import DataTable from '../components/DataTable';
import FormDialog from '../components/FormDialog';
import api from '../api/axios';

export default function PaymentsPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dlgOpen, setDlgOpen] = useState(false);
  const [edit, setEdit] = useState({ bookingId: '', amount: '', status: '', date: '' });

  const fetch = () => {
    setLoading(true);
    api.get('/payments')
       .then(r => setRows(r.data))
       .finally(() => setLoading(false));
  };
  useEffect(fetch, []);

  const columns = [
    { field: 'bookingId',    headerName: 'Booking ID', width: 180 },
    { field: 'amount',       headerName: 'Amount',     width: 120 },
    { field: 'status',       headerName: 'Status',     width: 130 },
    { field: 'date',         headerName: 'Date',       width: 150 },
    {
      field: 'actions', headerName: 'Actions', width: 120,
      renderCell: p => (
        <Button size="small" onClick={() => { setEdit(p.row); setDlgOpen(true); }}>
          Edit
        </Button>
      )
    }
  ];

  const handleSave = () => {
    const req = edit._id
      ? api.put(`/payments/${edit._id}`, edit)
      : api.post('/payments', edit);
    req.then(() => {
      fetch();
      setDlgOpen(false);
      setEdit({ bookingId: '', amount: '', status: '', date: '' });
    });
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>Payments</Typography>
      <Button variant="contained" sx={{ mb: 2 }}
              onClick={() => { setEdit({ bookingId: '', amount: '', status: '', date: '' }); setDlgOpen(true); }}>
        Add Payment
      </Button>
      <DataTable rows={rows} columns={columns} loading={loading} />

      <FormDialog
        open={dlgOpen}
        title={edit._id ? 'Edit Payment' : 'New Payment'}
        onClose={() => { setDlgOpen(false); setEdit({ bookingId: '', amount: '', status: '', date: '' }); }}
        onSave={handleSave}
      >
        <TextField
          fullWidth
          label="Booking ID"
          margin="normal"
          value={edit.bookingId}
          onChange={e => setEdit({ ...edit, bookingId: e.target.value })}
        />
        <TextField
          fullWidth
          label="Amount"
          type="number"
          margin="normal"
          value={edit.amount}
          onChange={e => setEdit({ ...edit, amount: e.target.value })}
        />
        <TextField
          fullWidth
          label="Status"
          select
          margin="normal"
          value={edit.status}
          onChange={e => setEdit({ ...edit, status: e.target.value })}
        >
          <MenuItem value="Pending">Pending</MenuItem>
          <MenuItem value="Completed">Completed</MenuItem>
          <MenuItem value="Failed">Failed</MenuItem>
        </TextField>
        <TextField
          fullWidth
          label="Date"
          type="datetime-local"
          margin="normal"
          InputLabelProps={{ shrink: true }}
          value={edit.date}
          onChange={e => setEdit({ ...edit, date: e.target.value })}
        />
      </FormDialog>
    </Box>
  );
}

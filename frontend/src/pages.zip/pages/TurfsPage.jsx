import React, { useState, useEffect } from 'react';
import { Button } from '@mui/material';
import DataTable from '../components/DataTable';
import FormDialog from '../components/FormDialog';
import api from '../api/axios';

export default function TurfsPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dlgOpen, setDlgOpen] = useState(false);
  const [editRow, setEditRow] = useState(null);

  const fetch = () => {
    setLoading(true);
    api.get('/turfs').then(r => setRows(r.data)).finally(() => setLoading(false));
  };
  useEffect(fetch, []);

  const columns = [
    { field: 'name', headerName: 'Name', width: 200 },
    { field: 'location', headerName: 'Location', width: 200 },
    { field: 'slots', headerName: 'Slots', width: 100, valueGetter: (r)=>r.row.slots.length },
    { field: 'actions', headerName: 'Actions', width: 150, renderCell: (params)=>(
        <Button size="small" onClick={()=>{ setEditRow(params.row); setDlgOpen(true); }}>
          Edit
        </Button>
      )
    },
  ];

  const handleSave = () => {
    // if editRow has _id → PUT /turfs/:id, else POST /turfs
    const req = editRow._id
      ? api.put(`/turfs/${editRow._id}`, editRow)
      : api.post('/turfs', editRow);
    req.then(()=>{ setDlgOpen(false); setEditRow(null); fetch(); });
  };

  return (
    <>
      <Button variant="contained" sx={{ m:2 }} onClick={()=>setDlgOpen(true)}>Add Turf</Button>
      <DataTable rows={rows} columns={columns} loading={loading} />
      <FormDialog open={dlgOpen}
                  title={editRow? 'Edit Turf' : 'Add Turf'}
                  onClose={()=>{setDlgOpen(false); setEditRow(null);}}
                  onSave={handleSave}>
        {/* Replace these with MUI TextField controls bound to editRow */}
        <input placeholder="Name" value={editRow?.name||''}
               onChange={e=>setEditRow({...editRow, name: e.target.value})}/>
      </FormDialog>
    </>
  );
}

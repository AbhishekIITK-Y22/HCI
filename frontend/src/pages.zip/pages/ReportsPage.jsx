// src/pages/ReportsPage.jsx
import React, { useState, useEffect } from 'react';
import { Box, Typography } from '@mui/material';
import api from '../api/axios';
// import your favorite charting lib, e.g. Recharts

export default function ReportsPage() {
  const [data, setData] = useState(null);
  useEffect(() => {
    api.get('/reports').then(r => setData(r.data));
  }, []);

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>Reports</Typography>
      {data ? (
        /* TODO: render Bar/Line charts with data */
        <Typography>Charts go here…</Typography>
      ) : (
        <Typography>Loading...</Typography>
      )}
    </Box>
  );
}

// src/pages/BookingPage.jsx
import React, { useState, useEffect } from 'react';
import { Box, Button, Typography } from '@mui/material';
import DataTable from '../components/DataTable';
import FormDialog from '../components/FormDialog';
import CalendarView from '../components/CalendarView';
import api from '../api/axios';
import dayjs from 'dayjs';

export default function BookingPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [month] = useState(dayjs().month() + 1);
  const [year]  = useState(dayjs().year());
  const [dlgOpen, setDlgOpen] = useState(false);
  const [edit, setEdit] = useState(null);

  const fetch = () => {
    setLoading(true);
    api.get('/bookings')
       .then(r => setRows(r.data))
       .finally(() => setLoading(false));
  };
  useEffect(fetch, []);

  const columns = [
    { field: 'customerName', headerName: 'Customer', width: 180 },
    { field: 'turfName',     headerName: 'Turf',     width: 150 },
    { field: 'date',         headerName: 'Date',     width: 120, valueGetter: r => dayjs(r.row.date).format('DD/MM/YYYY') },
    { field: 'start',        headerName: 'Start',    width: 100 },
    { field: 'end',          headerName: 'End',      width: 100 },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 130,
      renderCell: params => (
        <Button size="small" onClick={() => { setEdit(params.row); setDlgOpen(true); }}>
          Edit
        </Button>
      )
    }
  ];

  const handleSave = () => {
    const req = edit._id
      ? api.put(`/bookings/${edit._id}`, edit)
      : api.post('/bookings', edit);
    req.then(() => { fetch(); setDlgOpen(false); setEdit(null); });
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>Bookings</Typography>
      <Button variant="contained" sx={{ mb: 2 }} onClick={() => setDlgOpen(true)}>
        New Booking
      </Button>
      <DataTable rows={rows} columns={columns} loading={loading} />
      <Box sx={{ mt: 4 }}>
        <Typography variant="h6" gutterBottom>Calendar View</Typography>
        <CalendarView month={month} year={year} />
      </Box>
      <FormDialog
        open={dlgOpen}
        title={edit ? 'Edit Booking' : 'New Booking'}
        onClose={() => { setDlgOpen(false); setEdit(null); }}
        onSave={handleSave}
      >
        {/* TODO: replace with MUI TextField / DatePicker / TimePicker bound to `edit` */}
      </FormDialog>
    </Box>
  );
}
